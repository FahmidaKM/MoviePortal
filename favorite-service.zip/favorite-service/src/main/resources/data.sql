select * from favorite;





insert into movie(id,title,box_office,active,date_of_launch,genre,has_teaser) 
values(1,'Godha','3Cr',true,'2017-03-15','Action',true),
(2,'Queen','5Cr',true,'2017-12-23','Adventure',false),
(3,'Nizhal','4Cr',true,'2018-08-21','Adventure',false),
(4,'Hridayam','6Cr',false,'2017-07-02','Romance',true),
(5,'Superman','63Cr',true,'2022-11-02','Comedy',true);